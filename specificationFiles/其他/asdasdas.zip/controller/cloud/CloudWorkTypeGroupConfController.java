package top.tangyh.lamp.paigongyun.controller.cloud;


import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.tangyh.basic.base.R;
import top.tangyh.basic.base.controller.SuperController;
import top.tangyh.basic.interfaces.echo.EchoService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.service.cloud.CloudWorkTypeGroupConfService;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudWorkTypeGroupConfPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudWorkTypeGroupConfResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudWorkTypeGroupConfSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudWorkTypeGroupConfUpdateVO;

/**
 * <p>
 * 工种分组设置前端控制器
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
@Slf4j
@Validated
@RequiredArgsConstructor
@RestController
@RequestMapping("/cloudWorkTypeGroupConf")
@Api(value = "CloudWorkTypeGroupConf", tags = " 工种分组设置")
public class CloudWorkTypeGroupConfController extends SuperController<CloudWorkTypeGroupConfService, Long, CloudWorkTypeGroupConf, CloudWorkTypeGroupConfSaveVO, CloudWorkTypeGroupConfUpdateVO, CloudWorkTypeGroupConfPageQuery, CloudWorkTypeGroupConfResultVO> {
    @Autowired
    private CloudWorkTypeGroupConfService cloudWorkTypeGroupConfService;
    private final EchoService echoService;

    @Override
    public R<CloudWorkTypeGroupConf> save(CloudWorkTypeGroupConfSaveVO cloudWorkTypeGroupConfSaveVO) {
        boolean exits = cloudWorkTypeGroupConfService.checkWorkTypeConfNameExits(cloudWorkTypeGroupConfSaveVO);
        if(exits){
            return R.success(superService.save(cloudWorkTypeGroupConfSaveVO));
        }
        return R.fail("操作失败，请输入有效的工种ID！");
    }

    @Override
    public R<CloudWorkTypeGroupConf> update(CloudWorkTypeGroupConfUpdateVO cloudWorkTypeGroupConfUpdateVO) {
        boolean exits = cloudWorkTypeGroupConfService.checkWorkTypeConfNameExits(cloudWorkTypeGroupConfUpdateVO);
        if (exits){
            return R.success(superService.updateById(cloudWorkTypeGroupConfUpdateVO));
        }
        return R.fail("操作失败，请输入有效的工种ID！");
    }

    @Override
    public EchoService getEchoService() {
        return echoService;
    }
}
