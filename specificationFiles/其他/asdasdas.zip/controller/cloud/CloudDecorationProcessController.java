package top.tangyh.lamp.paigongyun.controller.cloud;


import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import top.tangyh.basic.base.R;
import top.tangyh.basic.base.controller.SuperController;
import top.tangyh.basic.interfaces.echo.EchoService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudDecorationProcess;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.service.cloud.CloudDecorationProcessService;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudDecorationProcessPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudDecorationProcessResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudDecorationProcessSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudDecorationProcessUpdateVO;

import java.util.List;

/**
 * <p>
 * 装修工序维护前端控制器
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
@Slf4j
@Validated
@RequiredArgsConstructor
@RestController
@RequestMapping("/cloudDecorationProcess")
@Api(value = "CloudDecorationProcess", tags = " 装修工序维护")
public class CloudDecorationProcessController extends SuperController<CloudDecorationProcessService, Long, CloudDecorationProcess, CloudDecorationProcessSaveVO, CloudDecorationProcessUpdateVO, CloudDecorationProcessPageQuery, CloudDecorationProcessResultVO> {


    private final EchoService echoService;
    private final CloudDecorationProcessService decorationProcessService;
    
    @Override
    public EchoService getEchoService() {
        return echoService;
    }

    /**
     * 添加工种Id
     * @param saveVO 保存参数
     * @return
     */
    @Override
    public R<CloudDecorationProcess> save(CloudDecorationProcessSaveVO saveVO) {
        decorationProcessService.setWorkTypeConfId(saveVO);
        return R.success(decorationProcessService.save(saveVO));
    }

    /**
     * 修改工种Id
     * @param updateVO 修改VO
     * @return
     */
    @Override
    public R<CloudDecorationProcess> update(CloudDecorationProcessUpdateVO updateVO) {
        decorationProcessService.setWorkTypeConfId(updateVO);
        return R.success(decorationProcessService.updateById(updateVO));
    }

    /**
     * 获取工种下小组集合
     * @param workTypeName
     * @return
     */
    @GetMapping("/getListByWorkTypeId/{workTypeName}")
    @ApiOperation(value = "获取工种下小组集合")
    public R<List<CloudWorkTypeGroupConf>> getListByWorkTypeId(@PathVariable String workTypeName) {
        List<CloudWorkTypeGroupConf> list = decorationProcessService.getListByWorkTypeId(workTypeName);
        return R.success(list);
    }

}
