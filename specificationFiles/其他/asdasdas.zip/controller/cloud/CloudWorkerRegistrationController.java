package top.tangyh.lamp.paigongyun.controller.cloud;


import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import top.tangyh.basic.annotation.constraints.NotEmptyPattern;
import top.tangyh.basic.base.R;
import top.tangyh.basic.base.controller.SuperController;
import top.tangyh.basic.base.entity.Entity;
import top.tangyh.basic.interfaces.echo.EchoService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkerRegistration;
import top.tangyh.lamp.paigongyun.service.cloud.CloudWorkerRegistrationService;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudWorkerRegistrationPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudWorkerRegistrationResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudWorkerRegistrationSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudWorkerRegistrationUpdateVO;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.ArrayList;

/**
 * <p>
 * 工人注册管理前端控制器
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
@Slf4j
@Validated
@RequiredArgsConstructor
@RestController
@RequestMapping("/cloudWorkerRegistration")
@Api(value = "CloudWorkerRegistration", tags = " 工人注册管理")
public class CloudWorkerRegistrationController extends SuperController<CloudWorkerRegistrationService, Long, CloudWorkerRegistration, CloudWorkerRegistrationSaveVO, CloudWorkerRegistrationUpdateVO, CloudWorkerRegistrationPageQuery, CloudWorkerRegistrationResultVO> {

    @Autowired
    private CloudWorkerRegistrationService cloudWorkerRegistrationService;

    private final EchoService echoService;

    /**
     * 注册工人
     * @param cloudWorkerRegistrationSaveVO
     * @return
     */
    @Override
    public R<CloudWorkerRegistration> save(CloudWorkerRegistrationSaveVO cloudWorkerRegistrationSaveVO) {
        //校验身份证
        if(cloudWorkerRegistrationService.checkIdNumber(cloudWorkerRegistrationSaveVO)){
            return R.fail("该身份证号码已注册！");
        }
        //设置工种ID
        cloudWorkerRegistrationService.setWorkTypeConfId(cloudWorkerRegistrationSaveVO);
        return R.success(superService.save(cloudWorkerRegistrationSaveVO));
    }

    @Override
    public R<CloudWorkerRegistration> update(CloudWorkerRegistrationUpdateVO cloudWorkerRegistrationUpdateVO) {
        //校验身份证
        if(!cloudWorkerRegistrationService.checkIdNumber(cloudWorkerRegistrationUpdateVO)){
            return R.fail("该身份证号码已注册！");
        }
        //设置工种ID
        cloudWorkerRegistrationService.updateWorkTypeConfId(cloudWorkerRegistrationUpdateVO);
        return R.success(superService.updateById(cloudWorkerRegistrationUpdateVO));
    }

    @Override
    public EchoService getEchoService() {
        return echoService;
    }
}
