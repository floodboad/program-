package top.tangyh.lamp.paigongyun.dao.cloud;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import top.tangyh.basic.base.mapper.SuperMapper;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeConf;

/**
 * <p>
 * 工种设置Mapper 接口
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
@Repository
@InterceptorIgnore(tenantLine = "true", dynamicTableName = "true")
public interface CloudWorkTypeConfMapper extends SuperMapper<CloudWorkTypeConf> {
    /**
     * 查出工种对应的工种ID
     * @param workTypeName
     * @return
     */
    Long getIdByWorkTypeName(@Param(value = "workTypeName") String workTypeName);
}
