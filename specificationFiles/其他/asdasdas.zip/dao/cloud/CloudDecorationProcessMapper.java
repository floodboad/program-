package top.tangyh.lamp.paigongyun.dao.cloud;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import feign.Param;
import org.springframework.stereotype.Repository;
import top.tangyh.basic.base.mapper.SuperMapper;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudDecorationProcess;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;

import java.util.List;

/**
 * <p>
 * 装修工序维护Mapper 接口
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
@Repository
@InterceptorIgnore(tenantLine = "true", dynamicTableName = "true")
public interface CloudDecorationProcessMapper extends SuperMapper<CloudDecorationProcess> {

    /**
     * 查询工种Id
     * @param workTypeName
     * @return
     */
    String selectWorkTypeConfId(@Param String workTypeName);

    /**
     * 查询工种小组Id
     * @param groupName
     * @return
     */
    String getCloudClassGroupId(@Param String groupName);

    /**
     * 获取工种下小组集合
     * @param workTypeName
     * @return
     */
    List<CloudWorkTypeGroupConf> getListByWorkTypeId(@Param String workTypeName);
}
