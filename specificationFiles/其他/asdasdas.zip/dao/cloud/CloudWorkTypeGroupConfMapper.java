package top.tangyh.lamp.paigongyun.dao.cloud;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import top.tangyh.basic.base.mapper.SuperMapper;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;

/**
 * <p>
 * 工种分组设置Mapper 接口
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
@Repository
@InterceptorIgnore(tenantLine = "true", dynamicTableName = "true")
public interface CloudWorkTypeGroupConfMapper extends SuperMapper<CloudWorkTypeGroupConf> {
    /**
     * 查工种ID
     * @param   cloudWorkTypeConf
     * @return 采用long的包装类型，这样查无结果可以用来判断为空
     */
    Long getWorkTypeConfId(@Param(value = "cloudWorkTypeConfId")Long cloudWorkTypeConf);
}
