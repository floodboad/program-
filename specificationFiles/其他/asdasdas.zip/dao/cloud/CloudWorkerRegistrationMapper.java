package top.tangyh.lamp.paigongyun.dao.cloud;

import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import top.tangyh.basic.base.mapper.SuperMapper;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkerRegistration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 工人注册管理Mapper 接口
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
@Repository
@InterceptorIgnore(tenantLine = "true", dynamicTableName = "true")
public interface CloudWorkerRegistrationMapper extends SuperMapper<CloudWorkerRegistration> {
    /**
     * 查询所有的身份证ID
     * @return ArrayList
     * 用于校验新增用户身份证的合法性
     */
    ArrayList<String> getIdNumberList();
}
