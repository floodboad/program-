package top.tangyh.lamp.paigongyun.service.cloud.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import top.tangyh.basic.base.service.impl.SuperServiceImpl;
import top.tangyh.lamp.common.constant.DsConstant;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeConf;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudWorkTypeConfManager;
import top.tangyh.lamp.paigongyun.service.cloud.CloudWorkTypeConfService;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudWorkTypeConfPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudWorkTypeConfResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudWorkTypeConfSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudWorkTypeConfUpdateVO;
import top.tangyh.lamp.paigongyun.common.constant.ADConstant;
/**
 * <p>
 * 工种设置业务实现类
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
@Slf4j
@Service
@DS(ADConstant.DS_DISPATCHING_CLOUD)
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CloudWorkTypeConfServiceImpl extends SuperServiceImpl<CloudWorkTypeConfManager, Long, CloudWorkTypeConf, CloudWorkTypeConfSaveVO, CloudWorkTypeConfUpdateVO, CloudWorkTypeConfPageQuery, CloudWorkTypeConfResultVO>
        implements CloudWorkTypeConfService {
    
}
