package top.tangyh.lamp.paigongyun.service.cloud.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import top.tangyh.basic.base.service.impl.SuperServiceImpl;
import top.tangyh.basic.utils.ArgumentAssert;
import top.tangyh.lamp.common.constant.DsConstant;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudDecorationProcess;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudDecorationProcessManager;
import top.tangyh.lamp.paigongyun.service.cloud.CloudDecorationProcessService;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudDecorationProcessPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudDecorationProcessResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudDecorationProcessSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudDecorationProcessUpdateVO;
import top.tangyh.lamp.paigongyun.common.constant.ADConstant;

import java.util.List;

/**
 * <p>
 * 装修工序维护业务实现类
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
@Slf4j
@Service
@DS(ADConstant.DS_DISPATCHING_CLOUD)
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CloudDecorationProcessServiceImpl extends SuperServiceImpl<CloudDecorationProcessManager, Long, CloudDecorationProcess, CloudDecorationProcessSaveVO, CloudDecorationProcessUpdateVO, CloudDecorationProcessPageQuery, CloudDecorationProcessResultVO>
        implements CloudDecorationProcessService {

    private final CloudDecorationProcessManager decorationProcessManager;

    /**
     * 添加工种Id
     * @param saveVO
     */
    @Override
    public void setWorkTypeConfId(CloudDecorationProcessSaveVO saveVO) {
        //查询工种Id
        String workTypeName = saveVO.getWorkTypeName();
        String workTypeId = decorationProcessManager.getWorkTypeConfId(workTypeName);

        //查询工种小组Id
        String groupName = saveVO.getGroupName();
        String cloudClassGroupId = decorationProcessManager.getCloudClassGroupId(groupName);

        //向saveVo中设置值
        saveVO.setCloudWorkTypeConfId(workTypeId);
        saveVO.setCloudClassGroupId(cloudClassGroupId);
    }

    /**
     * 修改工种Id
     * @param updateVO
     */
    @Override
    public void setWorkTypeConfId(CloudDecorationProcessUpdateVO updateVO) {
        String workTypeName = updateVO.getWorkTypeName();
        String workTypeId = decorationProcessManager.getWorkTypeConfId(workTypeName);

        updateVO.setCloudWorkTypeConfId(workTypeId);
    }

    /**
     * 获取工种下小组集合
     * @param workTypeName
     * @return
     */
    @Override
    public List<CloudWorkTypeGroupConf> getListByWorkTypeId(String workTypeName) {
        List<CloudWorkTypeGroupConf> list = decorationProcessManager.getListByWorkTypeId(workTypeName);
        return list;
    }


}
