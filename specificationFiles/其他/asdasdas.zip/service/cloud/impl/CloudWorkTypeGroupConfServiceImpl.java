package top.tangyh.lamp.paigongyun.service.cloud.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import top.tangyh.basic.base.service.impl.SuperServiceImpl;
import top.tangyh.lamp.common.constant.DsConstant;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudWorkTypeGroupConfManager;
import top.tangyh.lamp.paigongyun.service.cloud.CloudWorkTypeGroupConfService;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudWorkTypeGroupConfPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudWorkTypeGroupConfResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudWorkTypeGroupConfSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudWorkTypeGroupConfUpdateVO;
import top.tangyh.lamp.paigongyun.common.constant.ADConstant;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

/**
 * <p>
 * 工种分组设置业务实现类
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
@Slf4j
@Service
@DS(ADConstant.DS_DISPATCHING_CLOUD)
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CloudWorkTypeGroupConfServiceImpl extends SuperServiceImpl<CloudWorkTypeGroupConfManager, Long, CloudWorkTypeGroupConf, CloudWorkTypeGroupConfSaveVO, CloudWorkTypeGroupConfUpdateVO, CloudWorkTypeGroupConfPageQuery, CloudWorkTypeGroupConfResultVO>
        implements CloudWorkTypeGroupConfService {
    @Autowired
    private CloudWorkTypeGroupConfManager cloudWorkTypeGroupConfManager;
    @Override
    public boolean checkWorkTypeConfNameExits(CloudWorkTypeGroupConfSaveVO cloudWorkTypeGroupConfSaveVO) {
        String cloudWorkTypeConfId = cloudWorkTypeGroupConfSaveVO.getCloudWorkTypeConfId();
        long id = Long.parseLong(cloudWorkTypeConfId);
        Long workTypeConfId = cloudWorkTypeGroupConfManager.getWorkTypeConfId(id);
        if(workTypeConfId!=null){
            return true;
        }
        return false;
    }

    @Override
    public boolean checkWorkTypeConfNameExits(CloudWorkTypeGroupConfUpdateVO cloudWorkTypeGroupConfUpdateVO) {
        String cloudWorkTypeConfId = cloudWorkTypeGroupConfUpdateVO.getCloudWorkTypeConfId();
        long id = Long.parseLong(cloudWorkTypeConfId);
        Long workTypeConfId = cloudWorkTypeGroupConfManager.getWorkTypeConfId(id);
        if(workTypeConfId!=null){
            return true;
        }
        return false;
    }
}
