package top.tangyh.lamp.paigongyun.service.cloud.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import top.tangyh.basic.annotation.constraints.NotEmptyPattern;
import top.tangyh.basic.base.entity.Entity;
import top.tangyh.basic.base.service.impl.SuperServiceImpl;
import top.tangyh.lamp.common.constant.DsConstant;
import top.tangyh.lamp.paigongyun.common.constant.ADConstant;
import top.tangyh.lamp.paigongyun.dao.cloud.CloudWorkTypeConfMapper;
import top.tangyh.lamp.paigongyun.dao.cloud.CloudWorkerRegistrationMapper;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeConf;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkerRegistration;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudWorkTypeConfManager;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudWorkerRegistrationManager;
import top.tangyh.lamp.paigongyun.service.cloud.CloudWorkerRegistrationService;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudWorkerRegistrationPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudWorkerRegistrationResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudWorkerRegistrationSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudWorkerRegistrationUpdateVO;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.ArrayList;

/**
 * <p>
 * 工人注册管理业务实现类
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
@Slf4j
@Service
@DS(ADConstant.DS_DISPATCHING_CLOUD)
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CloudWorkerRegistrationServiceImpl extends SuperServiceImpl<CloudWorkerRegistrationManager, Long, CloudWorkerRegistration, CloudWorkerRegistrationSaveVO, CloudWorkerRegistrationUpdateVO, CloudWorkerRegistrationPageQuery, CloudWorkerRegistrationResultVO>
        implements CloudWorkerRegistrationService {
    @Autowired
    private CloudWorkerRegistrationManager cloudWorkerRegistrationManager;
    @Autowired
    private CloudWorkTypeConfManager cloudWorkTypeConfManager;
    @Override
    public ArrayList<String> getIdNumberList() {
        ArrayList<String> idNumberList = cloudWorkerRegistrationManager.getIdNumberList();
        return idNumberList;
    }

    @Override
    public boolean checkIdNumber(CloudWorkerRegistrationSaveVO cloudWorkerRegistrationSaveVO){
        //获取所有的身份证号码
        ArrayList<String> idNumberList = getIdNumberList();
        //获取要添加的身份证号码
        String idNumber = cloudWorkerRegistrationSaveVO.getIdNumber();
        //验证是否已经存在
        if(idNumberList.contains(idNumber)){
            return true;
        }
        return false;
    }

    @Override
    public boolean checkIdNumber(CloudWorkerRegistrationUpdateVO cloudWorkerRegistrationUpdateVO) {
        //获取所有的身份证号码
        ArrayList<String> idNumberList = getIdNumberList();
        //获取要添加的身份证号码
        String idNumber = cloudWorkerRegistrationUpdateVO.getIdNumber();
        //验证是否已经存在
        if(idNumberList.contains(idNumber)){
            return true;
        }
        return false;
    }

    @Override
    public CloudWorkerRegistrationSaveVO setWorkTypeConfId(CloudWorkerRegistrationSaveVO cloudWorkerRegistrationSaveVO) {
        //根据工种名查询ID，转换好类型后set入SaveVO并返回。
        String workTypeName = cloudWorkerRegistrationSaveVO.getWorkTypeName();
        String workTypeConfId = cloudWorkTypeConfManager.getIdByWorkTypeName(workTypeName).toString();
        cloudWorkerRegistrationSaveVO.setCloudWorkTypeConfId(workTypeConfId);
        return cloudWorkerRegistrationSaveVO;
    }

    @Override
    public CloudWorkerRegistrationUpdateVO updateWorkTypeConfId(CloudWorkerRegistrationUpdateVO cloudWorkerRegistrationUpdateVO) {
        //根据工种名查询ID，转换好类型后set入SaveVO并返回。
        String workTypeName = cloudWorkerRegistrationUpdateVO.getWorkTypeName();
        String workTypeConfId = cloudWorkTypeConfManager.getIdByWorkTypeName(workTypeName).toString();
        cloudWorkerRegistrationUpdateVO.setCloudWorkTypeConfId(workTypeConfId);
        return cloudWorkerRegistrationUpdateVO;
    }
}
