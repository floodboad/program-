package top.tangyh.lamp.paigongyun.service.cloud;

import top.tangyh.basic.base.service.SuperService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudDecorationProcess;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import top.tangyh.basic.base.service.SuperService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudDecorationProcess;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudDecorationProcessPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudDecorationProcessResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudDecorationProcessSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudDecorationProcessUpdateVO;

import java.util.List;

/**
 * <p>
 * 装修工序维护业务接口
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
public interface CloudDecorationProcessService extends SuperService<Long, CloudDecorationProcess, CloudDecorationProcessSaveVO, CloudDecorationProcessUpdateVO, CloudDecorationProcessPageQuery, CloudDecorationProcessResultVO> {

    //添加工种Id
    void setWorkTypeConfId(CloudDecorationProcessSaveVO saveVO);

    //修改工种Id
    void setWorkTypeConfId(CloudDecorationProcessUpdateVO updateVO);

    //获取工种下小组集合
    List<CloudWorkTypeGroupConf> getListByWorkTypeId(String workTypeName);
}
