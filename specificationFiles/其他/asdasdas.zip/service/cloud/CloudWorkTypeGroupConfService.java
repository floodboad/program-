package top.tangyh.lamp.paigongyun.service.cloud;

import top.tangyh.basic.base.service.SuperService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import top.tangyh.basic.base.service.SuperService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudWorkTypeGroupConfPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudWorkTypeGroupConfResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudWorkTypeGroupConfSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudWorkTypeGroupConfUpdateVO;
/**
 * <p>
 * 工种分组设置业务接口
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
public interface CloudWorkTypeGroupConfService extends SuperService<Long, CloudWorkTypeGroupConf, CloudWorkTypeGroupConfSaveVO, CloudWorkTypeGroupConfUpdateVO, CloudWorkTypeGroupConfPageQuery, CloudWorkTypeGroupConfResultVO> {
    /**
     * 校验该工种ID是否存在（存在才可用，有意义）
     * @param cloudWorkTypeGroupConfSaveVO
     * @return
     */
    boolean checkWorkTypeConfNameExits(CloudWorkTypeGroupConfSaveVO cloudWorkTypeGroupConfSaveVO);

    /**
     * 重载的校验方法
     * @param cloudWorkTypeGroupConfUpdateVO
     * @return
     */
    boolean checkWorkTypeConfNameExits(CloudWorkTypeGroupConfUpdateVO cloudWorkTypeGroupConfUpdateVO);
}
