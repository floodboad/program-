package top.tangyh.lamp.paigongyun.service.cloud;

import top.tangyh.basic.base.service.SuperService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkerRegistration;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import top.tangyh.basic.base.service.SuperService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkerRegistration;
import top.tangyh.lamp.paigongyun.vo.query.cloud.CloudWorkerRegistrationPageQuery;
import top.tangyh.lamp.paigongyun.vo.result.cloud.CloudWorkerRegistrationResultVO;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudWorkerRegistrationSaveVO;
import top.tangyh.lamp.paigongyun.vo.update.cloud.CloudWorkerRegistrationUpdateVO;

import java.util.ArrayList;

/**
 * <p>
 * 工人注册管理业务接口
 * 
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
public interface CloudWorkerRegistrationService extends SuperService<Long, CloudWorkerRegistration, CloudWorkerRegistrationSaveVO, CloudWorkerRegistrationUpdateVO, CloudWorkerRegistrationPageQuery, CloudWorkerRegistrationResultVO> {
    /**
     * 获取身份证号用于校验
     * @return
     */
    ArrayList<String> getIdNumberList();

    /**
     * 检验身份证号是否存在
     * @param cloudWorkerRegistrationSaveVO
     * @return
     */
    boolean checkIdNumber(CloudWorkerRegistrationSaveVO cloudWorkerRegistrationSaveVO);

    /**
     * 重载方法
     * @param cloudWorkerRegistrationUpdateVO
     * @return
     */
    boolean checkIdNumber(CloudWorkerRegistrationUpdateVO cloudWorkerRegistrationUpdateVO);

    /**
     * 配置工种ID
     * @param cloudWorkerRegistrationSaveVO,cloudWorkerRegistrationUpdateVO
     * @return
     */
    CloudWorkerRegistrationSaveVO setWorkTypeConfId(CloudWorkerRegistrationSaveVO cloudWorkerRegistrationSaveVO);
    /**
     * 修改工种ID
     * @param cloudWorkerRegistrationUpdateVO
     * @return
     */
    CloudWorkerRegistrationUpdateVO updateWorkTypeConfId(CloudWorkerRegistrationUpdateVO cloudWorkerRegistrationUpdateVO);

}
