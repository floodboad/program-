package top.tangyh.lamp.paigongyun.common.dispatchingCloud;

import top.tangyh.basic.base.entity.SuperEntity;
import top.tangyh.basic.cache.model.CacheKeyBuilder;
import top.tangyh.lamp.paigongyun.common.cache.CacheKeyModular;
import top.tangyh.lamp.paigongyun.common.cache.CacheKeyTable;

import java.time.Duration;

/**
 * @Class: CloudWorkTypeCacheKeyBuilder
 * @Author: MrSnow
 * @Date: 2022/4/24 15:18
 */
public class CloudWorkTypeCacheKeyBuilder implements CacheKeyBuilder {
    @Override
    public String getPrefix() {
        return CacheKeyModular.PREFIX;
    }

    @Override
    public String getModular() {
        return CacheKeyModular.DISPATCHING_CLOUD;
    }

    @Override
    public String getTable() {
        return CacheKeyTable.WORK_TYPE;
    }

    @Override
    public String getField() {
        return SuperEntity.ID_FIELD;
    }

    @Override
    public ValueType getValueType() {
        return ValueType.obj;
    }

    @Override
    public Duration getExpire() {
        return Duration.ofHours(24);
    }
}
