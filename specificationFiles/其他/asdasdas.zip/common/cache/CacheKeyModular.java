package top.tangyh.lamp.paigongyun.common.cache;

/**
 * @Class: CacheKeyModular
 * @Author: MrSnow
 * @Date: 2022/4/27 16:39
 */
public interface CacheKeyModular {
    String PREFIX = "lc";
    String DISPATCHING_CLOUD = "paigongyun";
    /**
     * 仅派工云服务paigongyun使用的缓存
     */

}
