package top.tangyh.lamp.paigongyun.common.cache;

/**
 * @author dz
 */
public interface CacheKeyTable {
    //paigongyun
    /**
     * 工种小组 前缀
     */
    String WORK_TYPE_GROUP = "cloud_work_type_group_conf";
    /**
     * 工种名称 前缀
     */
    String WORK_TYPE = "cloud_work_type_conf";
}
