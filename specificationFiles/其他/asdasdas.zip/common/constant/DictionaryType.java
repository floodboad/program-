package top.tangyh.lamp.paigongyun.common.constant;

/**
 * @author dz
 */
public interface DictionaryType {
    /**
     * 全局字典类型
     */
    interface Global{
        /**
         * 工种
         */
        String WORK_TYPE = "GLOBAL_WORK_TYPE";

        /**
         * 工种小组
         *
         */
        String WORK_TYPE_GROUP = "GLOBAL_WORK_TYPE_GROUP";

        /**
         * 工序类型
         * [01-普通验收 02-封闭验收 03-闭水验收]
         */
        String WORK_PROCESS = "GLOBAL_WORK_PROCESS";

    }
}
