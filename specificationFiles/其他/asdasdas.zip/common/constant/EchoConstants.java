package top.tangyh.lamp.paigongyun.common.constant;

/**
 * @author dz
 */
public class EchoConstants {
    /**
     * 小组名称 service查询类
     */
    public static final String WORK_TYPE_GROUP_CLASS = "CloudWorkTypeGroupConfManagerImpl";
    /**
     * 工种ID service查询类
     */
    public static final String WORK_TYPE_ID_CLASS = "CloudWorkTypeConfManagerImpl";
    /**
     * lamp-cloud 数据字典项 feign查询类 全类名
     */
    public static final String DICTIONARY_ITEM_FEIGN_CLASS = "top.tangyh.lamp.oauth.api.DictionaryApi";
}
