package top.tangyh.lamp.paigongyun.common.constant;
/**
 * @author lsb
 * @version v1.0
 * @date 2022/2/24 6:05 下午
 * @create [2022/2/24 10:50  ] [lsb] [初始创建]
 */
public interface ADConstant {
    /**
     * 派工云平台数据源
     */
    String DS_DISPATCHING_CLOUD="dispatching_cloud_1";
}
