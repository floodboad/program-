package top.tangyh.lamp.paigongyun.manager.cloud;

import top.tangyh.basic.base.manager.SuperManager;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkerRegistration;

import java.util.ArrayList;

/**
 * <p>
 * 工人注册管理业务层
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
public interface CloudWorkerRegistrationManager extends SuperManager<CloudWorkerRegistration> {
    /**
     * getIdNumberList
     * @return
     */
    ArrayList<String> getIdNumberList();
}
