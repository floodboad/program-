package top.tangyh.lamp.paigongyun.manager.cloud.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import top.tangyh.basic.base.manager.impl.SuperManagerImpl;
import top.tangyh.lamp.paigongyun.dao.cloud.CloudDecorationProcessMapper;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudDecorationProcess;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudDecorationProcessManager;

import java.util.List;

/**
 * <p>
 * 装修工序维护Manager
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
@RequiredArgsConstructor
@Service
public class CloudDecorationProcessManagerImpl extends SuperManagerImpl<CloudDecorationProcessMapper, CloudDecorationProcess> implements CloudDecorationProcessManager {

    private final CloudDecorationProcessMapper decorationProcessMapper;

    /**
     * 查询工种Id
     * @param workTypeName
     * @return
     */
    @Override
    public String getWorkTypeConfId(String workTypeName) {

        return decorationProcessMapper.selectWorkTypeConfId(workTypeName);
    }

    /**
     * 查询工种小组Id
     * @param groupName
     * @return
     */
    @Override
    public String getCloudClassGroupId(String groupName) {
        return decorationProcessMapper.getCloudClassGroupId(groupName);
    }

    /**
     * 获取工种下小组集合
     * @param workTypeName
     * @return
     */
    @Override
    public List<CloudWorkTypeGroupConf> getListByWorkTypeId(String workTypeName) {
        return decorationProcessMapper.getListByWorkTypeId(workTypeName);
    }

}
