package top.tangyh.lamp.paigongyun.manager.cloud.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import top.tangyh.basic.base.manager.impl.SuperManagerImpl;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkerRegistration;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudWorkerRegistrationManager;

import java.util.ArrayList;

/**
 * <p>
 * 工人注册管理Manager
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
@RequiredArgsConstructor
@Service
public class CloudWorkerRegistrationManagerImpl extends SuperManagerImpl<CloudWorkerRegistrationMapper, CloudWorkerRegistration> implements CloudWorkerRegistrationManager {
    @Autowired
    private CloudWorkerRegistrationMapper cloudWorkerRegistrationMapper;

    @Override
    public ArrayList<String> getIdNumberList() {
        ArrayList<String> idNumberList = cloudWorkerRegistrationMapper.getIdNumberList();
        return idNumberList;
    }
}
