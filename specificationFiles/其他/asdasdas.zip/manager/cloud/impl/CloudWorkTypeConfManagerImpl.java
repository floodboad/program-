package top.tangyh.lamp.paigongyun.manager.cloud.impl;

import cn.hutool.core.convert.Convert;
import com.baomidou.dynamic.datasource.annotation.DS;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import top.tangyh.basic.base.manager.impl.SuperCacheManagerImpl;
import top.tangyh.basic.cache.model.CacheKeyBuilder;
import top.tangyh.basic.utils.CollHelper;
import top.tangyh.lamp.paigongyun.common.dispatchingCloud.CloudWorkTypeCacheKeyBuilder;
import top.tangyh.lamp.paigongyun.common.constant.ADConstant;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeConf;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudWorkTypeConfManager;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 工种设置Manager
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
@RequiredArgsConstructor
@Service
public class CloudWorkTypeConfManagerImpl extends SuperCacheManagerImpl<CloudWorkTypeConfMapper, CloudWorkTypeConf> implements CloudWorkTypeConfManager {
    @Autowired
    private CloudWorkTypeConfMapper cloudWorkTypeConfMapper;

    @Override
    protected CacheKeyBuilder cacheKeyBuilder() {
        return new CloudWorkTypeCacheKeyBuilder();
    }

    private List<CloudWorkTypeConf> findWorkTypeName(Set<Serializable> ids){
        return findByIds(ids,
                         missIds -> super.listByIds(missIds.stream().filter(Objects::nonNull).map(Convert::toLong).collect(Collectors.toList())  )
        );
    }

    @Override
    public Long getIdByWorkTypeName(String workTypeName) {
         return cloudWorkTypeConfMapper.getIdByWorkTypeName(workTypeName);
    }

    @Transactional(readOnly = true)
    @DS(ADConstant.DS_DISPATCHING_CLOUD)
    @Override
    public Map<Serializable, Object> findByIds(Set<Serializable> ids) {
        return CollHelper.uniqueIndex(findWorkTypeName(ids),CloudWorkTypeConf::getId,CloudWorkTypeConf::getWorkTypeName);
    }
}
