package top.tangyh.lamp.paigongyun.manager.cloud.impl;

import cn.hutool.core.convert.Convert;
import com.baomidou.dynamic.datasource.annotation.DS;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import top.tangyh.basic.base.manager.impl.SuperCacheManagerImpl;

import top.tangyh.basic.cache.model.CacheKeyBuilder;
import top.tangyh.basic.utils.CollHelper;

import top.tangyh.lamp.paigongyun.common.dispatchingCloud.CloudWorkTypeGroupCacheBuilder;
import top.tangyh.lamp.paigongyun.common.constant.ADConstant;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.manager.cloud.CloudWorkTypeGroupConfManager;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * 工种分组设置Manager
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
@RequiredArgsConstructor
@Service
public class CloudWorkTypeGroupConfManagerImpl extends SuperCacheManagerImpl<CloudWorkTypeGroupConfMapper, CloudWorkTypeGroupConf> implements CloudWorkTypeGroupConfManager {
    @Autowired
    private CloudWorkTypeGroupConfMapper cloudWorkTypeGroupConfMapper;
    @Override
    protected CacheKeyBuilder cacheKeyBuilder() {
        return new CloudWorkTypeGroupCacheBuilder();
    }


    private List<CloudWorkTypeGroupConf> findGroupName(Set<Serializable> ids){
        return findByIds(ids,
                missIds -> super.listByIds(missIds.stream().filter(Objects::nonNull).map(Convert::toLong).collect(Collectors.toList()))
        );
    }

    @Transactional(readOnly = true)
    @Override
    @DS(ADConstant.DS_DISPATCHING_CLOUD)
    public Map<Serializable, Object> findByIds(Set<Serializable> ids) {
        return CollHelper.uniqueIndex(findGroupName(ids), CloudWorkTypeGroupConf::getId, CloudWorkTypeGroupConf::getGroupName);
    }

    @Override
    public Long getWorkTypeConfId(Long cloudWorkTypeConfId) {
        return cloudWorkTypeGroupConfMapper.getWorkTypeConfId(cloudWorkTypeConfId);
    }
}
