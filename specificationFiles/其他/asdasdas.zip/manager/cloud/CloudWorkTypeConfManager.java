package top.tangyh.lamp.paigongyun.manager.cloud;

import top.tangyh.basic.base.manager.SuperManager;
import top.tangyh.basic.interfaces.echo.LoadService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeConf;

/**
 * <p>
 * 工种设置业务层
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
public interface CloudWorkTypeConfManager extends SuperManager<CloudWorkTypeConf>, LoadService {
    /**
     * 查工种id
     * @param workTypeName
     * @return
     */
    Long getIdByWorkTypeName(String workTypeName);

}
