package top.tangyh.lamp.paigongyun.manager.cloud;

import top.tangyh.basic.base.manager.SuperManager;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudDecorationProcess;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;
import top.tangyh.lamp.paigongyun.vo.save.cloud.CloudDecorationProcessSaveVO;

import java.util.List;

/**
 * <p>
 * 装修工序维护业务层
 * </p>
 *
 * @author leonstart
 * @date 2022-04-11
 */
public interface CloudDecorationProcessManager extends SuperManager<CloudDecorationProcess> {

    //查询工种Id
    String getWorkTypeConfId(String workTypeName);

    //查询工种小组Id
    String getCloudClassGroupId(String groupName);

    //获取工种下小组集合
    List<CloudWorkTypeGroupConf> getListByWorkTypeId(String workTypeName);
}
