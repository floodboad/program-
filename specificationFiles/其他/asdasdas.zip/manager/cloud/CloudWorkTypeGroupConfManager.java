package top.tangyh.lamp.paigongyun.manager.cloud;

import org.apache.ibatis.annotations.Param;
import top.tangyh.basic.base.manager.SuperManager;
import top.tangyh.basic.interfaces.echo.LoadService;
import top.tangyh.lamp.paigongyun.entity.cloud.CloudWorkTypeGroupConf;

/**
 * <p>
 * 工种分组设置业务层
 * </p>
 *
 * @author leonstart
 * @date 2022-04-20
 */
public interface CloudWorkTypeGroupConfManager extends SuperManager<CloudWorkTypeGroupConf>, LoadService {
    /**
     * 同对应Mapper中的方法
     * @param cloudWorkTypeConfId
     * @return
     */
    Long getWorkTypeConfId(Long cloudWorkTypeConfId);
}
